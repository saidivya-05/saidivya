import mongoose from 'mongoose';
import bcrypt from 'bcrypt';

const userSchema = new mongoose.Schema({
  username: {
    type: String,
    required: true
  },
  email: {
    type: String,
    unique: true
  },
  password: {
    type: String,
    required: true
  },
  oldPassword: {
    type: String,
    required: true
 },
  newPassword: {
    type: String,
    required: true
  },
  jobtitle: {
    type: String
  },
  department: {
    type: String
  },
  age: {
    type: Number
  },
 location: {
    type: String
 },
 salary: {
    type: String
 }
}, {
  timestamps: true
});

userSchema.pre('save', async function (next) {
  const salt = await bcrypt.genSalt(10);
  this.password = await bcrypt.hash(this.password, salt);
  next();
});


export default mongoose.model('User', userSchema);
