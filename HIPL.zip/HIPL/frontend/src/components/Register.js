import React, { useState } from 'react';
import API from '../api';
import { toast } from 'react-toastify';

const Register = () => {
  const [formData, setFormData] = useState({ username: '',  password: '' });

  const handleSubmit = async (e) => {
    e.preventDefault();
    try {
      await API.post('/register', formData);
      toast.success('Registration successful!');
    } catch (err) {
      toast.error(err.response?.data?.message || 'Error during registration');
    }
  };

  return (
    <form onSubmit={handleSubmit}>
        <h1>HEALTHOFINNVATION</h1>
        <h4>Login into the Dashboard</h4>
      <input
        type="text"
        placeholder="Username"
        value={formData.name}
        onChange={(e) => setFormData({ ...formData, name: e.target.value })}
        required
      />
      <input
        type="password"
        placeholder="Password"
        value={formData.password}
        onChange={(e) => setFormData({ ...formData, password: e.target.value })}
        required
      />
      <p>Forgot Password</p>
      <button type="submit">New Signup</button>
      <button type="submit">LogIn Now</button>
    </form>
  );
};

export default Register;