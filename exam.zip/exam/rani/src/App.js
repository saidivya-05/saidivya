import './App.css';
import Callback from './components/Callback'
import Performance from './components/Performance'
import Toggle from './components/Toggle'
import Api from './components/Api'
import Products from './components/Products'
import Submitbutton from './components/Submitbutton'
import PaginationChange from './components/PaginationChange';
import { PaginationContextProvider } from './components/PaginationContextProvider';
//import Lazyimg from './components/Lazyimg'
function App() {
  return (
    <div className="App">
      <Callback/>
      <hr></hr>
      <Performance/>
      <hr></hr>
      <Toggle/>
      <hr></hr>
      <Api/>
      <hr></hr>
      <Products/>
      <hr></hr>
      <Submitbutton/>
      <hr></hr>
      <div>
        <PaginationContextProvider>
          <PaginationChange></PaginationChange>

        </PaginationContextProvider>
      </div>
      <hr></hr>
       {/* <Lazyimg/> */}
    </div>
  );
}
export default App;