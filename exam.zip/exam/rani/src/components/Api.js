import React, { useEffect, useState } from "react"; 

export default function Useeffect() {
    const [products,setproducts]=useState([])
    useEffect(()=>{
        fetch("https://fakestoreapi.com/products")
        .then(result=>result.json())
        .then(user=>setproducts(user))
    }
    )
  return (
    <div>
        {products.map(item=>
            <div>
                <p><b>id: </b>{item.id}</p>
                <p><b>title : </b>{item.title}</p>
                <p><b>price : </b>{item.price}</p>
                <p><b>description:</b>{item.description}</p>
                <p><b>category:</b>{item.category}</p>
                <img src={item.image}></img>  
                <p><b>rating:</b></p>
                <p><b>rate: </b>{item.rating.rate}</p>
                <p><b>count: </b>{item.rating.count}</p>
          </div>
        )}
    </div>
  )
}