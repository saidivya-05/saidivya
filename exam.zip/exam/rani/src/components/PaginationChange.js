import React, { useContext } from 'react';
import { PaginationContext } from './PaginationContextProvider';

const PaginationChange = () => {
    const { currentPage, nextPage, prevPage } = useContext(PaginationContext);

    return (
        <>
        <div className='pagination-change-app'>
            <h1>Current Page: {currentPage}</h1>
            <button onClick={prevPage} className='pagination-change-btn'>Previous Page</button>
            
            <button onClick={nextPage} className='pagination-change-btn'>Next Page</button>
        </div>
        </>
    );
};

export default PaginationChange;
