import React, { useState, useEffect } from "react";

const ImageCarousel = ({ images }) => {
  const [currentIndex, setCurrentIndex] = useState(0);

  // Auto-cycling through images every 5 seconds
  useEffect(() => {
    const timer = setInterval(() => {
      setCurrentIndex((prevIndex) => (prevIndex + 1) % images.length);
    }, 5000);
    return () => clearInterval(timer);
  }, [images]);

  // Lazy load image based on visibility
  const lazyLoadImage = (index) =>
    index === currentIndex ? images[index] : "r1img.jpg";

  const goToNext = () => {
    setCurrentIndex((currentIndex + 1) % images.length);
  };

  const goToPrevious = () => {
    setCurrentIndex(
      (currentIndex - 1 + images.length) % images.length
    );
  };

  return (
    <div className="carousel">
      <button onClick={goToPrevious}>Previous</button>
      <img
        src={lazyLoadImage(currentIndex)}
        alt={Slide `${currentIndex}`}
        style={{ width: "100%", height: "auto" }}
      />
      <button onClick={goToNext}>Next</button>
    </div>
  );
};

export default ImageCarousel;