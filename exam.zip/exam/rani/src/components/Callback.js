import React, { useState, useCallback } from 'react';
const Item = React.memo(({ item }) => {
  console.log(`Rendering item: ${item}`);
  return <div>{item}</div>;
});

function TodoList() {
  const [items, setItems] = useState([]);
  const [newItem, setNewItem] = useState('');
  const addItem = useCallback(() => {
    setItems((prevItems) => [...prevItems, newItem]);
    setNewItem('');
  }, [newItem]);

  return (
    <div>
      <h1>Todo List</h1>
      <input
        type="text"
        value={newItem}
        onChange={(e) => setNewItem(e.target.value)}
      />
      <button onClick={addItem}>Add Item</button>
      <ul>
        {items.map((item, index) => (
          <li key={index}>
            <Item item={item} />
          </li>
        ))}
      </ul>
    </div>
  );
}

export default TodoList;

