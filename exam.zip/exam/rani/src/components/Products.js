import React, { useState, useEffect, useMemo } from "react";

const FetchDataWithUseMemo = () => {
  const [category, setCategory] = useState("posts");
  const [data, setData] = useState([]);

  useEffect(() => {
    const fetchData = async () => {
      const response = await fetch(`https://fakestoreapi.com/products`);
      const result = await response.json();
      setData(result);
    };
    fetchData();
  }, [category]);

  const memoizedData = useMemo(() => data, [data]);

  return (
    <div>
      <select value={category} onChange={(e) => setCategory(e.target.value)}>
        <option value="posts">Posts</option>
        <option value="users">Users</option>
        <option value="comments">Comments</option>
      </select>

      <ul>
        {memoizedData.map((item) => (
            <div>
                <p><b>id: </b>{item.id}</p>
                <p><b>title : </b>{item.title}</p>
                <p><b>price : </b>{item.price}</p>
                <p><b>description:</b>{item.description}</p>
                <p><b>category:</b>{item.category}</p>
                <img src={item.image}></img>  
                <p><b>rating:</b></p>
                <p><b>rate: </b>{item.rating.rate}</p>
                <p><b>count: </b>{item.rating.count}</p>
          </div>
        ))}
      </ul>
    </div>
  );
};

export default FetchDataWithUseMemo;